/**
 * Simple C++ program using variables.
 * 
 * @author
 *   Wade Fagen-Ulmschneider <waf@illinois.edu>
 */

#include <iostream>

int main() {
  int i = 4;
  i = i + 2;
  
  char c = 'a';

  std::cout << i << " " << c << std::endl;

  return 0;
}